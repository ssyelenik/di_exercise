# Exercise 1

1. Create a variable called **name**, and give it your name as a value (text)
2. Create a variable called **age**, and give it your age as a value (number)
3. Create a variable called **shoe_size**, and give it your shoe size as a value
4. Create a variable called **info**. Its value should be an interesting sentence about yourself, including your name, age, and shoe size. Use the variables you created earlier.
5. Write code so that when your script is run, the info message is prompt on the screen.
   Run your code